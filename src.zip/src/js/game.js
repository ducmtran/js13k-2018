var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
window.addEventListener('keyup', function (event) {
  Key.onKeyup(event);
}, false);
window.addEventListener('keydown', function (event) {
  Key.onKeydown(event);
}, false);
var lastTime, current, dt;

// initialize global variables, state etc
function init() {
  state = 'playing'; //playing, paused
  fragments = [];
  grid.initialize(3);
  kontra.keys.bind(['up', 'down', 'left', 'right', 'space'], function(e) {
    e.preventDefault();
    ship.inputQueue.unshift(e.keyCode);
  });

  // fragments.push(create_fragment(100, 200, 0, -2, 'red'));
  // fragments.push(create_fragment(100, 300, 0, -3, 'blue'));
  // fragments.push(create_fragment(300, 100, -3, 0, 'red'));
  // fragments.push(create_fragment(230, 100, -2, 0, 'blue'));
  spawnRandomFragments(2);
}

let loop_k = kontra.gameLoop({
  fps: 60,
  clearCanvas: true,
  update: function (dt) {
    ship.handleInput();
    collision();
    for (let i = 0; i < fragments.length; i++) {
      fragments[i].update();
    }
    ship.update();
    Key.update();
  },
  render: function () {
    grid.render();
    for (let i = 0; i < fragments.length; i++) {
      fragments[i].render();
    }
    ship.render();
  }
})

init();
loop_k.start();
// setInterval(loop, 16);

// setInterval(loop);