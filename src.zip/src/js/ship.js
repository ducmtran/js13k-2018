var ship = kontra.sprite({
  x: 200,
  y: 200,
  color: 'red',
  width: 30,
  height: 30,
  dx: -1,
  dy: -1,
  isGrabbing: false,
  grabFrag: -1,
  maxSpeed: 4,
  inputQueue: [],

  handleInput: function () {
    // movement
    if (Key.isDown(Key.UP)) {
      this.ddy = -0.15;
    }
    else if (Key.isDown(Key.DOWN)) {
      this.ddy = 0.15;
    }
    else this.ddy = 0;

    if (Key.isDown(Key.LEFT)) {
      this.ddx = -0.15;
    }
    else if (Key.isDown(Key.RIGHT)) {
      this.ddx = 0.15;
    }
    else this.ddx = 0;

    // grab/ungrab
    if (Key.released(Key.SPACE)) {
      console.log('grab');
      if (!this.isGrabbing) {
        this.grab();
      } else {
        this.ungrab();
      }
    }

  },

  grab: function () {
    for (let i = 0; i < fragments.length; i++) {
      // check nearby with x axis first
      if (Math.abs(this.x - fragments[i].x) < 50) {
        if (distanceSquared(this, fragments[i]) < 900) {
          // match speed with fragment
          fragments[i].grabbed = true;
          this.isGrabbing = true;
          this.grabbing = i;
          this.dx = 0;
          this.dy = 0;
          this.ddx = 0;
          this.ddy = 0;
          return;
        }
      }
    }
  },

  ungrab: function () {
    this.isGrabbing = false;
    fragments[this.grabbing].grabbed = false;
    this.grabbing = -1;
  },

  update: function () {

    if (this.x < 0) this.dx = Math.abs(this.dx);
    if (this.x > 360) this.dx = -Math.abs(this.dx);
    if (this.y > 360) this.dy = -Math.abs(this.dy);
    if (this.y < 0) this.dy = Math.abs(this.dy);

    // limit ship's speed
    if (this.dx > this.maxSpeed) this.dx = this.maxSpeed;
    else if (this.dx < -this.maxSpeed) this.dx = -this.maxSpeed;
    if (this.dy > this.maxSpeed) this.dy = this.maxSpeed;
    else if (this.dy < -this.maxSpeed) this.dy = -this.maxSpeed;


    this.advance();
  },
});


kontra.keys.bind(['up', 'down', 'left', 'right', 'space'], function (e) {
  e.preventDefault();
  ship.inputQueue.unshift(e.keyCode);
});